# rag/router.py
import re
from typing import Dict, List, Any, Optional

_FW_MAP = {
    "ifrs": "IFRS",
    "aaoifi": "AAOIFI",
    "cbb": "CBB",
    "internal": "InternalPolicy",
    "internal policy": "InternalPolicy",
    "policy": "InternalPolicy",
}

def _detect_frameworks(q: str) -> List[str]:
    ql = q.lower()
    fws = []
    for k, v in _FW_MAP.items():
        if k in ql and v not in fws:
            fws.append(v)
    # lightweight heuristics: if the question mentions sukuk + measurement, often IFRS/AAOIFI
    if ("sukuk" in ql or "ijarah" in ql) and not fws:
        fws += ["AAOIFI", "IFRS"]
    return fws

def classify_intent_and_scope(query: str, mode_hint: Optional[str] = None) -> Dict[str, Any]:
    q = query.strip()
    ql = q.lower()

    # Manual override from UI
    if mode_hint:
        m = mode_hint.lower()
        if m in ("regulatory","regulatory_analysis"):  # frameworks prioritized if present
            return {"intent": "regulatory", "frameworks": _detect_frameworks(q), "needs_web": False}
        if m in ("research",):
            return {"intent": "research", "frameworks": [], "needs_web": True}
        if m in ("quick","quick_fact"):
            return {"intent": "quick_fact", "frameworks": [], "needs_web": True}
        if m in ("mixed","mixed_compare"):
            fws = _detect_frameworks(q) or ["IFRS","AAOIFI","CBB","InternalPolicy"]
            return {"intent": "mixed_compare", "frameworks": fws, "needs_web": True}

    # Heuristics
    research_triggers = [
        "market", "compare to market", "industry", "revenue", "npl", "ratio", "growth",
        "statistics", "latest", "today", "as of", "bahrain banking", "sector", "market size",
        "press release", "news",
    ]
    quick_triggers = ["define", "what is", "difference between", "vs", "meaning of"]
    regulatory_triggers = ["under ifrs", "according to ifrs", "under aaoifi", "under cbb", "rulebook", "policy", "impairment", "ecl", "sppi", "held to maturity"]

    if any(t in ql for t in research_triggers):
        # If it also references frameworks, treat as mixed compare
        fws = _detect_frameworks(q)
        if fws:
            return {"intent": "mixed_compare", "frameworks": fws, "needs_web": True}
        return {"intent": "research", "frameworks": [], "needs_web": True}

    if any(t in ql for t in quick_triggers) and len(q.split()) <= 14:
        # Keep quick facts as web-enabled so we can cite fresh facts
        return {"intent": "quick_fact", "frameworks": [], "needs_web": True}

    fws = _detect_frameworks(q)
    if fws:
        return {"intent": "regulatory", "frameworks": fws, "needs_web": False}

    # Default: regulatory (auto frameworks)
    return {"intent": "regulatory", "frameworks": [], "needs_web": False}
